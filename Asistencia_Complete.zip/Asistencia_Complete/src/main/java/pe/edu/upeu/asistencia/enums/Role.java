package pe.edu.upeu.asistencia.enums;

public enum Role { ADMIN, EMPLEADO }
