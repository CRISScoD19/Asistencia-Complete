package pe.edu.upeu.asistencia.enums;

public enum Facultad {
    FIA,
    FCE,
    FCS,
    FACIHED,
    GENERAL
}
