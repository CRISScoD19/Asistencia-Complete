package pe.edu.upeu.asistencia.enums;

public enum TipoParticipante {
    ASISTENTE, ORGANIZADOR, PONENTE
}
