package pe.edu.upeu.asistencia;

public class Aplicacion {
    public static void main(String[] args) {
        System.out.println("hello world");
        AsistenciaApplication.main(args);
    }
}