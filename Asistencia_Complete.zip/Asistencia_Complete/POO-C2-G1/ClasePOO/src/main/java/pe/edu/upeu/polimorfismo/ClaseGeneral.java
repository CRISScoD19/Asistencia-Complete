package pe.edu.upeu.polimorfismo;

public class ClaseGeneral {
    public static void main(String[] args) {
        gato G = new gato();
        G.sonido();
        G.dormir();
    }
}
