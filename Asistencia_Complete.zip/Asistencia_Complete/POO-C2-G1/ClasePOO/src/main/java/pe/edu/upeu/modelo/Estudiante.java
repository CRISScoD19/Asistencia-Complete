package pe.edu.upeu.modelo;

public class Estudiante {
}
