package pe.edu.upeu.herencia;

public class Vehiculo {
    String marca = "MERCEDES";

    public void sonido (){
        System.out.println("ruuuun runnn ");

    }
}
