package pe.edu.upeu.polimorfismo;

public class gato extends Animal{

    @Override
    public void sonido(){
        System.out.println("miauuu.....miauuu");
    }
    public void dormir (){
        System.out.println("ZZZzzzzzZZZZzzz...ZZZZzzZzz");
    }
}
