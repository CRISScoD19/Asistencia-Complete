package pe.edu.upeu.polimorfismo;

public class Animal {
    public void sonido(){
        System.out.println("Emitir sonido....sonidooo");

    }
    public void dormir (){
        System.out.println("pov: se duerme xd");
    }
}
