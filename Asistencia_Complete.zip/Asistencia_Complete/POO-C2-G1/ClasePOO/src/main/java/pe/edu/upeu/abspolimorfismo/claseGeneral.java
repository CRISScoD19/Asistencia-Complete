package pe.edu.upeu.abspolimorfismo;

public class claseGeneral {

    public static void main(String[] args) {
        gato g = new gato();
        g.emitirSonido();
        g.dormir();
    }
}
